// 간단한 키오스크 애플리케이션 (오프라인 모드)
class SimpleKioskApp {
    constructor() {
        this.currentScreen = 'welcome';
        this.cart = [];
        this.categories = [];
        this.menus = [];
        this.currentCategory = null;
        
        this.init();
    }
    
    init() {
        this.loadSampleData();
        this.setupEventListeners();
        this.updateTime();
        this.showWelcome();
    }
    
    loadSampleData() {
        // 샘플 카테고리 데이터
        this.categories = [
            { id: 1, name: '메인메뉴', icon: '🍽️', display_order: 1 },
            { id: 2, name: '사이드메뉴', icon: '🍟', display_order: 2 },
            { id: 3, name: '음료', icon: '🥤', display_order: 3 },
            { id: 4, name: '디저트', icon: '🍰', display_order: 4 },
            { id: 5, name: 'Freethai 추천', icon: '🍜', display_order: 5 }
        ];
        
        // 샘플 메뉴 데이터
        this.menus = [
            // 메인메뉴
            { id: 1, category_id: 1, name: '불고기버거', description: '한국식 불고기 패티와 신선한 야채', price: 8900, image_url: null, is_popular: true, display_order: 1 },
            { id: 2, category_id: 1, name: '치킨버거', description: '바삭한 치킨 패티와 특제 소스', price: 7900, image_url: null, is_popular: false, display_order: 2 },
            { id: 3, category_id: 1, name: '새우버거', description: '통새우 패티와 타르타르 소스', price: 9900, image_url: null, is_popular: true, display_order: 3 },
            { id: 4, category_id: 1, name: '치즈버거', description: '더블 치즈와 신선한 야채', price: 6900, image_url: null, is_popular: false, display_order: 4 },
            
            // 사이드메뉴
            { id: 5, category_id: 2, name: '감자튀김', description: '바삭한 감자튀김', price: 2500, image_url: null, is_popular: true, display_order: 1 },
            { id: 6, category_id: 2, name: '치킨너겟', description: '바삭한 치킨너겟 6개', price: 3500, image_url: null, is_popular: false, display_order: 2 },
            { id: 7, category_id: 2, name: '양파링', description: '바삭한 양파링', price: 3000, image_url: null, is_popular: false, display_order: 3 },
            { id: 8, category_id: 2, name: '치즈스틱', description: '치즈가 가득한 치즈스틱 4개', price: 4000, image_url: null, is_popular: true, display_order: 4 },
            
            // 음료
            { id: 9, category_id: 3, name: '콜라', description: '시원한 콜라', price: 2000, image_url: null, is_popular: true, display_order: 1 },
            { id: 10, category_id: 3, name: '사이다', description: '시원한 사이다', price: 2000, image_url: null, is_popular: false, display_order: 2 },
            { id: 11, category_id: 3, name: '오렌지주스', description: '신선한 오렌지주스', price: 3000, image_url: null, is_popular: false, display_order: 3 },
            { id: 12, category_id: 3, name: '아메리카노', description: '진한 아메리카노', price: 3500, image_url: null, is_popular: true, display_order: 4 },
            
            // 디저트
            { id: 13, category_id: 4, name: '아이스크림', description: '바닐라 아이스크림', price: 2000, image_url: null, is_popular: true, display_order: 1 },
            { id: 14, category_id: 4, name: '초콜릿케이크', description: '진한 초콜릿 케이크', price: 4500, image_url: null, is_popular: false, display_order: 2 },
            { id: 15, category_id: 4, name: '치즈케이크', description: '부드러운 치즈케이크', price: 4000, image_url: null, is_popular: true, display_order: 3 },
            { id: 16, category_id: 4, name: '애플파이', description: '달콤한 애플파이', price: 3500, image_url: null, is_popular: false, display_order: 4 },
            
            // Freethai 추천
            { id: 17, category_id: 5, name: '울버린이 말아주는 무삥', description: '열개의 손마디로 구워주는 돼지고기 꼬치', price: 3500, image_url: null, is_popular: true, display_order: 1 }
        ];
    }
    
    setupEventListeners() {
        // 언어 선택
        document.querySelectorAll('.lang-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
            });
        });
        
        // 결제 방법 선택
        document.querySelectorAll('.payment-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.payment-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
            });
        });
        
        // 키보드 이벤트
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.showWelcome();
            }
        });
    }
    
    updateTime() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('ko-KR', { 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit',
            hour12: true 
        });
        
        const timeElement = document.getElementById('current-time');
        if (timeElement) {
            timeElement.textContent = timeString;
        }
        
        setTimeout(() => this.updateTime(), 1000);
    }
    
    showScreen(screenId) {
        document.querySelectorAll('.screen').forEach(screen => {
            screen.classList.remove('active');
        });
        document.getElementById(screenId).classList.add('active');
        this.currentScreen = screenId;
    }
    
    showWelcome() {
        this.showScreen('welcome-screen');
    }
    
    showCategories() {
        this.showScreen('category-screen');
        this.renderCategories();
    }
    
    showMenus(categoryId) {
        this.showScreen('menu-screen');
        this.currentCategory = categoryId;
        this.renderMenus();
    }
    
    showCart() {
        this.showScreen('cart-screen');
        this.renderCart();
    }
    
    showCheckout() {
        this.showScreen('checkout-screen');
        this.renderCheckout();
    }
    
    showOrderComplete(orderNumber) {
        this.showScreen('order-complete-screen');
        document.getElementById('order-number').textContent = orderNumber;
    }
    
    renderCategories() {
        const container = document.getElementById('category-grid');
        if (!container) return;
        
        container.innerHTML = '';
        
        this.categories.forEach(category => {
            const categoryCard = document.createElement('div');
            categoryCard.className = 'category-card';
            categoryCard.innerHTML = `
                <div class="category-icon">${category.icon}</div>
                <div class="category-name">${category.name}</div>
            `;
            categoryCard.addEventListener('click', () => this.showMenus(category.id));
            container.appendChild(categoryCard);
        });
    }
    
    renderMenus() {
        const container = document.getElementById('menu-grid');
        if (!container) return;
        
        container.innerHTML = '';
        
        const categoryMenus = this.menus.filter(menu => menu.category_id === this.currentCategory);
        
        categoryMenus.forEach(menu => {
            const menuCard = document.createElement('div');
            menuCard.className = 'menu-card';
            menuCard.innerHTML = `
                <div class="menu-image">
                    <i class="fas fa-utensils"></i>
                </div>
                <div class="menu-info">
                    <h3 class="menu-name">${menu.name}</h3>
                    <p class="menu-description">${menu.description}</p>
                    <div class="menu-price">₩${menu.price.toLocaleString()}</div>
                </div>
                <div class="menu-actions">
                    <button class="add-to-cart-btn" onclick="app.addToCart(${menu.id})">
                        <i class="fas fa-plus"></i>
                    </button>
                </div>
            `;
            
            // 메뉴 카드 클릭 시 장바구니에 추가
            menuCard.addEventListener('click', (e) => {
                // 버튼 클릭이 아닌 경우에만 장바구니에 추가
                if (!e.target.closest('.add-to-cart-btn')) {
                    this.addToCart(menu.id);
                }
            });
            
            container.appendChild(menuCard);
        });
    }
    
    addToCart(menuId) {
        const menu = this.menus.find(m => m.id === menuId);
        if (!menu) return;
        
        const existingItem = this.cart.find(item => item.id === menuId);
        if (existingItem) {
            existingItem.quantity += 1;
            existingItem.total_price = existingItem.quantity * existingItem.unit_price;
        } else {
            this.cart.push({
                id: menu.id,
                name: menu.name,
                unit_price: menu.price,
                quantity: 1,
                total_price: menu.price
            });
        }
        
        this.updateCartBadge();
        
        // 시각적 피드백
        this.showAddToCartFeedback(menu.name);
    }
    
    showAddToCartFeedback(menuName) {
        // 기존 피드백 제거
        const existingFeedback = document.querySelector('.add-to-cart-feedback');
        if (existingFeedback) {
            existingFeedback.remove();
        }
        
        // 새 피드백 생성
        const feedback = document.createElement('div');
        feedback.className = 'add-to-cart-feedback';
        feedback.innerHTML = `
            <div class="feedback-content">
                <i class="fas fa-check-circle"></i>
                <span>${menuName}이(가) 장바구니에 추가되었습니다!</span>
            </div>
        `;
        
        // 스타일 추가
        feedback.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #4CAF50;
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            z-index: 1000;
            font-size: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            animation: fadeInOut 2s ease-in-out;
        `;
        
        // 애니메이션 CSS 추가
        if (!document.querySelector('#feedback-styles')) {
            const style = document.createElement('style');
            style.id = 'feedback-styles';
            style.textContent = `
                @keyframes fadeInOut {
                    0% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
                    20% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
                    80% { opacity: 1; transform: translate(-50%, -50%) scale(1); }
                    100% { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
                }
            `;
            document.head.appendChild(style);
        }
        
        document.body.appendChild(feedback);
        
        // 2초 후 제거
        setTimeout(() => {
            if (feedback.parentNode) {
                feedback.remove();
            }
        }, 2000);
    }
    
    updateCartBadge() {
        const badge = document.querySelector('.cart-badge');
        const navBadge = document.querySelector('#nav-cart-count');
        const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
        
        if (badge) {
            badge.textContent = totalItems;
        }
        if (navBadge) {
            navBadge.textContent = totalItems;
        }
    }
    
    renderCart() {
        const container = document.getElementById('cart-items');
        if (!container) return;
        
        container.innerHTML = '';
        
        if (this.cart.length === 0) {
            container.innerHTML = '<div class="empty-cart">장바구니가 비어있습니다.</div>';
            return;
        }
        
        this.cart.forEach((item, index) => {
            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item';
            cartItem.innerHTML = `
                <div class="item-info">
                    <h4>${item.name}</h4>
                    <p>₩${item.unit_price.toLocaleString()}</p>
                </div>
                <div class="item-controls">
                    <button onclick="app.updateQuantity(${index}, -1)">-</button>
                    <span>${item.quantity}</span>
                    <button onclick="app.updateQuantity(${index}, 1)">+</button>
                </div>
                <div class="item-total">₩${item.total_price.toLocaleString()}</div>
                <button class="remove-btn" onclick="app.removeFromCart(${index})">
                    <i class="fas fa-trash"></i>
                </button>
            `;
            container.appendChild(cartItem);
        });
        
        this.renderCartTotal();
    }
    
    updateQuantity(index, change) {
        const item = this.cart[index];
        item.quantity += change;
        
        if (item.quantity <= 0) {
            this.cart.splice(index, 1);
        } else {
            item.total_price = item.quantity * item.unit_price;
        }
        
        this.renderCart();
        this.updateCartBadge();
    }
    
    removeFromCart(index) {
        this.cart.splice(index, 1);
        this.renderCart();
        this.updateCartBadge();
    }
    
    renderCartTotal() {
        const total = this.cart.reduce((sum, item) => sum + item.total_price, 0);
        const tax = Math.round(total * 0.1);
        const grandTotal = total + tax;
        
        document.getElementById('subtotal').textContent = `₩${total.toLocaleString()}`;
        document.getElementById('tax').textContent = `₩${tax.toLocaleString()}`;
        document.getElementById('total').textContent = `₩${grandTotal.toLocaleString()}`;
    }
    
    renderCheckout() {
        this.renderCartTotal();
    }
    
    async processPayment() {
        const paymentMethod = document.querySelector('.payment-btn.active');
        if (!paymentMethod) {
            alert('결제 방법을 선택해주세요');
            return;
        }
        
        // 결제 시뮬레이션
        const orderNumber = 'ORD' + Date.now();
        
        // 2초 대기 (결제 처리 시뮬레이션)
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // 주문 완료
        this.cart = [];
        this.updateCartBadge();
        this.showOrderComplete(orderNumber);
    }
    
    startNewOrder() {
        this.cart = [];
        this.updateCartBadge();
        this.showWelcome();
    }
    
    closeHelp() {
        document.getElementById('help-modal').style.display = 'none';
    }
    
    showHelp() {
        document.getElementById('help-modal').style.display = 'block';
    }
}

// 전역 변수로 앱 인스턴스 생성
let app;

// DOM 로드 완료 후 앱 초기화
document.addEventListener('DOMContentLoaded', () => {
    app = new SimpleKioskApp();
});
