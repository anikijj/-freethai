// 키오스크 최적화 모듈
class KioskOptimization {
    constructor() {
        this.isKioskMode = true;
        this.idleTimer = null;
        this.idleTimeout = 300000; // 5분
        this.touchOptimized = true;
        
        this.init();
    }
    
    init() {
        this.setupKioskMode();
        this.setupTouchOptimization();
        this.setupIdleTimeout();
        this.setupErrorHandling();
        this.setupAccessibility();
        this.setupPerformanceOptimization();
    }
    
    setupKioskMode() {
        // 전체화면 모드
        if (this.isKioskMode) {
            this.enterFullscreen();
        }
        
        // 컨텍스트 메뉴 비활성화
        document.addEventListener('contextmenu', (e) => {
            e.preventDefault();
        });
        
        // 키보드 단축키 비활성화
        document.addEventListener('keydown', (e) => {
            // F11, F12, Ctrl+Shift+I 등 개발자 도구 단축키 비활성화
            if (e.key === 'F11' || e.key === 'F12' || 
                (e.ctrlKey && e.shiftKey && e.key === 'I')) {
                e.preventDefault();
            }
        });
        
        // 선택 비활성화
        document.addEventListener('selectstart', (e) => {
            e.preventDefault();
        });
        
        // 드래그 비활성화
        document.addEventListener('dragstart', (e) => {
            e.preventDefault();
        });
    }
    
    enterFullscreen() {
        if (document.documentElement.requestFullscreen) {
            document.documentElement.requestFullscreen().catch(err => {
                console.log('전체화면 모드 진입 실패:', err);
            });
        }
    }
    
    setupTouchOptimization() {
        // 터치 이벤트 최적화
        document.addEventListener('touchstart', (e) => {
            // 터치 피드백
            this.addTouchFeedback(e.target);
        }, { passive: true });
        
        document.addEventListener('touchend', (e) => {
            // 터치 피드백 제거
            this.removeTouchFeedback(e.target);
        }, { passive: true });
        
        // 더블탭 줌 방지
        document.addEventListener('touchstart', (e) => {
            if (e.touches.length > 1) {
                e.preventDefault();
            }
        });
        
        // 핀치 줌 방지
        document.addEventListener('touchmove', (e) => {
            if (e.touches.length > 1) {
                e.preventDefault();
            }
        }, { passive: false });
    }
    
    addTouchFeedback(element) {
        if (element && element.classList) {
            element.classList.add('touch-active');
        }
    }
    
    removeTouchFeedback(element) {
        if (element && element.classList) {
            setTimeout(() => {
                element.classList.remove('touch-active');
            }, 150);
        }
    }
    
    setupIdleTimeout() {
        // 사용자 활동 감지
        const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'];
        
        events.forEach(event => {
            document.addEventListener(event, () => {
                this.resetIdleTimer();
            }, true);
        });
        
        this.resetIdleTimer();
    }
    
    resetIdleTimer() {
        clearTimeout(this.idleTimer);
        this.idleTimer = setTimeout(() => {
            this.handleIdleTimeout();
        }, this.idleTimeout);
    }
    
    handleIdleTimeout() {
        // 대기 화면으로 돌아가기
        if (window.app && window.app.showWelcome) {
            window.app.showWelcome();
        }
        
        // 화면 보호기 효과
        this.showScreenSaver();
    }
    
    showScreenSaver() {
        const screensaver = document.createElement('div');
        screensaver.id = 'screensaver';
        screensaver.innerHTML = `
            <div class="screensaver-content">
                <div class="screensaver-logo">
                    <i class="fas fa-utensils"></i>
                    <h1>KISK</h1>
                </div>
                <p>화면을 터치하여 주문을 시작하세요</p>
                <div class="screensaver-animation">
                    <div class="pulse-circle"></div>
                </div>
            </div>
        `;
        
        screensaver.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            color: white;
            text-align: center;
        `;
        
        document.body.appendChild(screensaver);
        
        // 화면 보호기 클릭 시 제거
        screensaver.addEventListener('click', () => {
            document.body.removeChild(screensaver);
            this.resetIdleTimer();
        });
    }
    
    setupErrorHandling() {
        // 오프라인 모드: 모든 오류 핸들러 비활성화
        console.log('오프라인 모드: 오류 핸들러 비활성화');
    }
    
    setupAccessibility() {
        // 고대비 모드 지원
        this.detectHighContrast();
        
        // 키보드 네비게이션 지원
        this.setupKeyboardNavigation();
        
        // 스크린 리더 지원
        this.setupScreenReaderSupport();
    }
    
    detectHighContrast() {
        // 고대비 모드 감지
        if (window.matchMedia && window.matchMedia('(prefers-contrast: high)').matches) {
            document.body.classList.add('high-contrast');
        }
    }
    
    setupKeyboardNavigation() {
        // Tab 키 네비게이션
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                // 포커스 가능한 요소들만 순환
                const focusableElements = document.querySelectorAll(
                    'button, input, select, textarea, [tabindex]:not([tabindex="-1"])'
                );
                
                const currentIndex = Array.from(focusableElements).indexOf(document.activeElement);
                const nextIndex = e.shiftKey ? 
                    (currentIndex - 1 + focusableElements.length) % focusableElements.length :
                    (currentIndex + 1) % focusableElements.length;
                
                focusableElements[nextIndex]?.focus();
                e.preventDefault();
            }
        });
    }
    
    setupScreenReaderSupport() {
        // ARIA 라벨 추가
        this.addAriaLabels();
        
        // 상태 변경 알림
        this.setupStatusAnnouncements();
    }
    
    addAriaLabels() {
        // 버튼들에 ARIA 라벨 추가
        document.querySelectorAll('button').forEach(button => {
            if (!button.getAttribute('aria-label') && !button.textContent.trim()) {
                button.setAttribute('aria-label', '버튼');
            }
        });
        
        // 이미지들에 alt 텍스트 추가
        document.querySelectorAll('img').forEach(img => {
            if (!img.getAttribute('alt')) {
                img.setAttribute('alt', '이미지');
            }
        });
    }
    
    setupStatusAnnouncements() {
        // 상태 변경 시 스크린 리더에 알림
        const announcer = document.createElement('div');
        announcer.setAttribute('aria-live', 'polite');
        announcer.setAttribute('aria-atomic', 'true');
        announcer.style.cssText = `
            position: absolute;
            left: -10000px;
            width: 1px;
            height: 1px;
            overflow: hidden;
        `;
        document.body.appendChild(announcer);
        
        this.announcer = announcer;
    }
    
    announce(message) {
        if (this.announcer) {
            this.announcer.textContent = message;
        }
    }
    
    setupPerformanceOptimization() {
        // 이미지 지연 로딩
        this.setupLazyLoading();
        
        // 메모리 사용량 모니터링
        this.monitorMemoryUsage();
        
        // 캐시 최적화
        this.setupCacheOptimization();
    }
    
    setupLazyLoading() {
        // Intersection Observer를 사용한 지연 로딩
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        if (img.dataset.src) {
                            img.src = img.dataset.src;
                            img.removeAttribute('data-src');
                            imageObserver.unobserve(img);
                        }
                    }
                });
            });
            
            document.querySelectorAll('img[data-src]').forEach(img => {
                imageObserver.observe(img);
            });
        }
    }
    
    monitorMemoryUsage() {
        // 메모리 사용량 체크 (개발 환경에서만)
        if (performance.memory) {
            setInterval(() => {
                const memory = performance.memory;
                const usedMB = Math.round(memory.usedJSHeapSize / 1048576);
                const totalMB = Math.round(memory.totalJSHeapSize / 1048576);
                
                if (usedMB / totalMB > 0.8) {
                    console.warn('메모리 사용량이 높습니다:', usedMB + 'MB / ' + totalMB + 'MB');
                }
            }, 30000); // 30초마다 체크
        }
    }
    
    setupCacheOptimization() {
        // 서비스 워커 등록 (PWA 지원)
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js').catch(err => {
                console.log('Service Worker 등록 실패:', err);
            });
        }
    }
    
    showErrorMessage(message) {
        const errorModal = document.createElement('div');
        errorModal.className = 'error-modal';
        errorModal.innerHTML = `
            <div class="error-content">
                <i class="fas fa-exclamation-triangle"></i>
                <h3>오류</h3>
                <p>${message}</p>
                <button onclick="this.parentElement.parentElement.remove()">확인</button>
            </div>
        `;
        
        errorModal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
            color: white;
        `;
        
        document.body.appendChild(errorModal);
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            z-index: 10000;
            animation: slideInRight 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
    
    // 키오스크 모드 토글
    toggleKioskMode() {
        this.isKioskMode = !this.isKioskMode;
        
        if (this.isKioskMode) {
            this.enterFullscreen();
            this.setupKioskMode();
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            }
        }
    }
    
    // 터치 최적화 토글
    toggleTouchOptimization() {
        this.touchOptimized = !this.touchOptimized;
        document.body.classList.toggle('touch-optimized', this.touchOptimized);
    }
}

// CSS 애니메이션 추가
const style = document.createElement('style');
style.textContent = `
    .touch-active {
        transform: scale(0.95);
        transition: transform 0.1s ease;
    }
    
    .high-contrast {
        filter: contrast(150%) brightness(120%);
    }
    
    .screensaver-content {
        text-align: center;
    }
    
    .screensaver-logo {
        margin-bottom: 30px;
    }
    
    .screensaver-logo i {
        font-size: 80px;
        margin-bottom: 20px;
        animation: pulse 2s infinite;
    }
    
    .screensaver-logo h1 {
        font-size: 48px;
        font-weight: 700;
        margin: 0;
    }
    
    .screensaver-animation {
        margin-top: 40px;
    }
    
    .pulse-circle {
        width: 20px;
        height: 20px;
        background: white;
        border-radius: 50%;
        margin: 0 auto;
        animation: pulse 2s infinite;
    }
    
    .error-content {
        background: white;
        color: #2c3e50;
        padding: 30px;
        border-radius: 15px;
        text-align: center;
        max-width: 400px;
    }
    
    .error-content i {
        font-size: 48px;
        color: #e74c3c;
        margin-bottom: 20px;
    }
    
    .error-content h3 {
        font-size: 24px;
        margin-bottom: 15px;
    }
    
    .error-content button {
        background: #3498db;
        color: white;
        border: none;
        padding: 12px 24px;
        border-radius: 8px;
        cursor: pointer;
        font-size: 16px;
        margin-top: 20px;
    }
    
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .touch-optimized button,
    .touch-optimized .category-card,
    .touch-optimized .menu-card {
        min-height: 60px;
        min-width: 60px;
    }
`;
document.head.appendChild(style);

// 키오스크 최적화 초기화
let kioskOptimization;
document.addEventListener('DOMContentLoaded', () => {
    kioskOptimization = new KioskOptimization();
});
