// 관리자 대시보드 애플리케이션
class AdminApp {
    constructor() {
        this.currentSection = 'dashboard';
        this.token = localStorage.getItem('admin_token');
        this.categories = [];
        this.menus = [];
        this.orders = [];
        this.settings = {};
        
        this.init();
    }
    
    async init() {
        this.setupEventListeners();
        this.updateTime();
        
        if (this.token) {
            await this.loadData();
            this.showDashboard();
        } else {
            this.showLogin();
        }
    }
    
    setupEventListeners() {
        // 로그인 폼
        document.getElementById('login-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleLogin();
        });
        
        // 네비게이션
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const section = item.dataset.section;
                this.showSection(section);
            });
        });
        
        // 기간 선택
        document.querySelectorAll('.period-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.period-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                this.loadStatistics(e.target.dataset.period);
            });
        });
        
        // 필터
        document.getElementById('order-status-filter').addEventListener('change', () => {
            this.filterOrders();
        });
        
        document.getElementById('order-date-filter').addEventListener('change', () => {
            this.filterOrders();
        });
        
        // 모달 닫기
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeAllModals();
            }
        });
    }
    
    updateTime() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('ko-KR', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        const timeElement = document.getElementById('admin-time');
        if (timeElement) {
            timeElement.textContent = timeString;
        }
        
        setTimeout(() => this.updateTime(), 1000);
    }
    
    async handleLogin() {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        try {
            this.showLoading(true);
            
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });
            
            const data = await response.json();
            
            if (response.ok) {
                this.token = data.token;
                localStorage.setItem('admin_token', this.token);
                document.getElementById('admin-name').textContent = data.user.name;
                await this.loadData();
                this.showDashboard();
            } else {
                throw new Error(data.error || '로그인 실패');
            }
        } catch (error) {
            alert('로그인 실패: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }
    
    logout() {
        this.token = null;
        localStorage.removeItem('admin_token');
        this.showLogin();
    }
    
    showLogin() {
        document.getElementById('login-screen').classList.add('active');
        document.getElementById('admin-dashboard').classList.remove('active');
    }
    
    showDashboard() {
        document.getElementById('login-screen').classList.remove('active');
        document.getElementById('admin-dashboard').classList.add('active');
        this.showSection('dashboard');
    }
    
    showSection(section) {
        // 모든 섹션 숨기기
        document.querySelectorAll('.content-section').forEach(sec => {
            sec.classList.remove('active');
        });
        
        // 모든 네비게이션 아이템 비활성화
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        
        // 선택된 섹션 표시
        document.getElementById(`${section}-section`).classList.add('active');
        document.querySelector(`[data-section="${section}"]`).classList.add('active');
        
        // 페이지 제목 업데이트
        const titles = {
            dashboard: '대시보드',
            orders: '주문 관리',
            menus: '메뉴 관리',
            categories: '카테고리 관리',
            statistics: '통계',
            settings: '설정'
        };
        document.getElementById('page-title').textContent = titles[section];
        
        this.currentSection = section;
        
        // 섹션별 데이터 로드
        switch (section) {
            case 'dashboard':
                this.loadDashboard();
                break;
            case 'orders':
                this.loadOrders();
                break;
            case 'menus':
                this.loadMenus();
                break;
            case 'categories':
                this.loadCategories();
                break;
            case 'statistics':
                this.loadStatistics('today');
                break;
            case 'settings':
                this.loadSettings();
                break;
        }
    }
    
    async loadData() {
        await Promise.all([
            this.loadCategories(),
            this.loadMenus(),
            this.loadSettings()
        ]);
    }
    
    async loadDashboard() {
        try {
            // 통계 데이터 로드
            const [salesResponse, ordersResponse] = await Promise.all([
                fetch('/api/statistics?period=today', {
                    headers: { 'Authorization': `Bearer ${this.token}` }
                }),
                fetch('/api/orders', {
                    headers: { 'Authorization': `Bearer ${this.token}` }
                })
            ]);
            
            const salesData = await salesResponse.json();
            const ordersData = await ordersResponse.json();
            
            // 대시보드 업데이트
            document.getElementById('today-sales').textContent = 
                `₩${salesData.sales.total_sales.toLocaleString()}`;
            document.getElementById('today-orders').textContent = 
                `${salesData.sales.total_orders}건`;
            
            const pendingOrders = ordersData.filter(order => order.order_status === 'pending').length;
            document.getElementById('pending-orders').textContent = `${pendingOrders}건`;
            
            document.getElementById('total-menus').textContent = `${this.menus.length}개`;
            
            // 인기 메뉴 표시
            this.renderPopularMenus(salesData.popular_menus);
            
            // 주문 차트
            this.renderOrdersChart(ordersData);
            
        } catch (error) {
            console.error('대시보드 데이터 로드 실패:', error);
        }
    }
    
    async loadOrders() {
        try {
            const response = await fetch('/api/orders', {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });
            this.orders = await response.json();
            this.renderOrders();
        } catch (error) {
            console.error('주문 데이터 로드 실패:', error);
        }
    }
    
    renderOrders() {
        const tbody = document.getElementById('orders-table-body');
        tbody.innerHTML = '';
        
        this.orders.forEach(order => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${order.order_number}</td>
                <td>${new Date(order.order_date).toLocaleString('ko-KR')}</td>
                <td>${order.customer_name || '-'}</td>
                <td>${order.menu_items || '-'}</td>
                <td>₩${order.total_amount.toLocaleString()}</td>
                <td>${this.getPaymentMethodText(order.payment_method)}</td>
                <td><span class="status-badge status-${order.order_status}">${this.getStatusText(order.order_status)}</span></td>
                <td>
                    <button class="action-btn" onclick="adminApp.updateOrderStatus(${order.id}, 'preparing')">준비중</button>
                    <button class="action-btn" onclick="adminApp.updateOrderStatus(${order.id}, 'ready')">완료</button>
                    <button class="action-btn danger" onclick="adminApp.updateOrderStatus(${order.id}, 'cancelled')">취소</button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }
    
    async updateOrderStatus(orderId, status) {
        try {
            const response = await fetch(`/api/orders/${orderId}/status`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.token}`
                },
                body: JSON.stringify({ order_status: status })
            });
            
            if (response.ok) {
                this.loadOrders();
                alert('주문 상태가 업데이트되었습니다');
            } else {
                throw new Error('주문 상태 업데이트 실패');
            }
        } catch (error) {
            alert('주문 상태 업데이트 실패: ' + error.message);
        }
    }
    
    filterOrders() {
        const statusFilter = document.getElementById('order-status-filter').value;
        const dateFilter = document.getElementById('order-date-filter').value;
        
        let filteredOrders = this.orders;
        
        if (statusFilter) {
            filteredOrders = filteredOrders.filter(order => order.order_status === statusFilter);
        }
        
        if (dateFilter) {
            const filterDate = new Date(dateFilter).toDateString();
            filteredOrders = filteredOrders.filter(order => 
                new Date(order.order_date).toDateString() === filterDate
            );
        }
        
        this.renderFilteredOrders(filteredOrders);
    }
    
    renderFilteredOrders(orders) {
        const tbody = document.getElementById('orders-table-body');
        tbody.innerHTML = '';
        
        orders.forEach(order => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${order.order_number}</td>
                <td>${new Date(order.order_date).toLocaleString('ko-KR')}</td>
                <td>${order.customer_name || '-'}</td>
                <td>${order.menu_items || '-'}</td>
                <td>₩${order.total_amount.toLocaleString()}</td>
                <td>${this.getPaymentMethodText(order.payment_method)}</td>
                <td><span class="status-badge status-${order.order_status}">${this.getStatusText(order.order_status)}</span></td>
                <td>
                    <button class="action-btn" onclick="adminApp.updateOrderStatus(${order.id}, 'preparing')">준비중</button>
                    <button class="action-btn" onclick="adminApp.updateOrderStatus(${order.id}, 'ready')">완료</button>
                    <button class="action-btn danger" onclick="adminApp.updateOrderStatus(${order.id}, 'cancelled')">취소</button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }
    
    async loadMenus() {
        try {
            const response = await fetch('/api/menus');
            this.menus = await response.json();
            this.renderMenus();
        } catch (error) {
            console.error('메뉴 데이터 로드 실패:', error);
        }
    }
    
    renderMenus() {
        const container = document.getElementById('menus-grid');
        container.innerHTML = '';
        
        this.menus.forEach(menu => {
            const card = document.createElement('div');
            card.className = 'menu-card';
            card.innerHTML = `
                <div class="card-header">
                    <div>
                        <div class="card-title">${menu.name}</div>
                        <div class="card-price">₩${menu.price.toLocaleString()}</div>
                    </div>
                    <div class="card-actions">
                        <button class="edit-btn" onclick="adminApp.editMenu(${menu.id})">수정</button>
                        <button class="delete-btn" onclick="adminApp.deleteMenu(${menu.id})">삭제</button>
                    </div>
                </div>
                <div class="card-image">
                    ${menu.image_url ? 
                        `<img src="${menu.image_url}" alt="${menu.name}">` : 
                        '<i class="fas fa-utensils"></i>'
                    }
                </div>
                <div class="card-description">${menu.description || ''}</div>
            `;
            container.appendChild(card);
        });
    }
    
    async loadCategories() {
        try {
            const response = await fetch('/api/categories');
            this.categories = await response.json();
            this.renderCategories();
        } catch (error) {
            console.error('카테고리 데이터 로드 실패:', error);
        }
    }
    
    renderCategories() {
        const container = document.getElementById('categories-grid');
        container.innerHTML = '';
        
        this.categories.forEach(category => {
            const card = document.createElement('div');
            card.className = 'category-card';
            card.innerHTML = `
                <div class="card-header">
                    <div>
                        <div class="card-title">${category.name}</div>
                    </div>
                    <div class="card-actions">
                        <button class="edit-btn" onclick="adminApp.editCategory(${category.id})">수정</button>
                        <button class="delete-btn" onclick="adminApp.deleteCategory(${category.id})">삭제</button>
                    </div>
                </div>
                <div class="card-image">
                    <i class="${category.icon || 'fas fa-utensils'}"></i>
                </div>
            `;
            container.appendChild(card);
        });
    }
    
    async loadStatistics(period) {
        try {
            const response = await fetch(`/api/statistics?period=${period}`, {
                headers: { 'Authorization': `Bearer ${this.token}` }
            });
            const data = await response.json();
            
            this.renderSalesChart(data);
            this.renderPaymentChart(data);
        } catch (error) {
            console.error('통계 데이터 로드 실패:', error);
        }
    }
    
    async loadSettings() {
        try {
            const response = await fetch('/api/settings');
            this.settings = await response.json();
            
            // 설정 폼에 값 채우기
            Object.keys(this.settings).forEach(key => {
                const input = document.getElementById(key.replace('_', '-'));
                if (input) {
                    input.value = this.settings[key];
                }
            });
        } catch (error) {
            console.error('설정 데이터 로드 실패:', error);
        }
    }
    
    async saveSettings() {
        try {
            const formData = new FormData();
            formData.append('store_name', document.getElementById('store-name').value);
            formData.append('store_phone', document.getElementById('store-phone').value);
            formData.append('store_address', document.getElementById('store-address').value);
            formData.append('tax_rate', document.getElementById('tax-rate').value);
            
            const response = await fetch('/api/settings', {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${this.token}`
                },
                body: formData
            });
            
            if (response.ok) {
                alert('설정이 저장되었습니다');
            } else {
                throw new Error('설정 저장 실패');
            }
        } catch (error) {
            alert('설정 저장 실패: ' + error.message);
        }
    }
    
    showAddMenuModal() {
        document.getElementById('menu-modal').classList.add('active');
        document.getElementById('menu-modal-title').textContent = '메뉴 추가';
        document.getElementById('menu-form').reset();
        this.loadCategoryOptions();
    }
    
    showAddCategoryModal() {
        document.getElementById('category-modal').classList.add('active');
        document.getElementById('category-modal-title').textContent = '카테고리 추가';
        document.getElementById('category-form').reset();
    }
    
    async loadCategoryOptions() {
        const select = document.getElementById('menu-category');
        select.innerHTML = '';
        
        this.categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            select.appendChild(option);
        });
    }
    
    closeMenuModal() {
        document.getElementById('menu-modal').classList.remove('active');
    }
    
    closeCategoryModal() {
        document.getElementById('category-modal').classList.remove('active');
    }
    
    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.remove('active');
        });
    }
    
    showLoading(show) {
        const overlay = document.getElementById('loading-overlay');
        if (show) {
            overlay.classList.add('active');
        } else {
            overlay.classList.remove('active');
        }
    }
    
    // 유틸리티 함수들
    getPaymentMethodText(method) {
        const methods = {
            card: '신용카드',
            mobile: '모바일페이',
            cash: '현금'
        };
        return methods[method] || method;
    }
    
    getStatusText(status) {
        const statuses = {
            pending: '대기',
            preparing: '준비중',
            ready: '완료',
            completed: '완료',
            cancelled: '취소'
        };
        return statuses[status] || status;
    }
    
    renderPopularMenus(menus) {
        const container = document.getElementById('popular-menus');
        container.innerHTML = '';
        
        menus.slice(0, 5).forEach((menu, index) => {
            const item = document.createElement('div');
            item.className = 'popular-menu-item';
            item.innerHTML = `
                <div class="rank">${index + 1}</div>
                <div class="name">${menu.name}</div>
                <div class="quantity">${menu.total_quantity}개</div>
            `;
            container.appendChild(item);
        });
    }
    
    renderOrdersChart(orders) {
        const ctx = document.getElementById('orders-chart');
        if (!ctx) return;
        
        // 차트 데이터 준비
        const last7Days = [];
        const orderCounts = [];
        
        for (let i = 6; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            last7Days.push(date.toLocaleDateString('ko-KR', { month: 'short', day: 'numeric' }));
            
            const dayOrders = orders.filter(order => {
                const orderDate = new Date(order.order_date);
                return orderDate.toDateString() === date.toDateString();
            });
            orderCounts.push(dayOrders.length);
        }
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: last7Days,
                datasets: [{
                    label: '주문 수',
                    data: orderCounts,
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
                }
        });
    }
    
    renderSalesChart(data) {
        const ctx = document.getElementById('sales-chart');
        if (!ctx) return;
        
        // 매출 차트 구현
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['월', '화', '수', '목', '금', '토', '일'],
                datasets: [{
                    label: '매출',
                    data: [120000, 150000, 180000, 200000, 250000, 300000, 280000],
                    backgroundColor: 'rgba(52, 152, 219, 0.8)'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
    
    renderPaymentChart(data) {
        const ctx = document.getElementById('payment-chart');
        if (!ctx) return;
        
        // 결제 방법별 차트 구현
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['신용카드', '모바일페이', '현금'],
                datasets: [{
                    data: [60, 30, 10],
                    backgroundColor: ['#3498db', '#2ecc71', '#f39c12']
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
}

// 전역 함수들
function logout() {
    adminApp.logout();
}

function showAddMenuModal() {
    adminApp.showAddMenuModal();
}

function showAddCategoryModal() {
    adminApp.showAddCategoryModal();
}

function closeMenuModal() {
    adminApp.closeMenuModal();
}

function closeCategoryModal() {
    adminApp.closeCategoryModal();
}

function saveSettings() {
    adminApp.saveSettings();
}

function loadOrders() {
    adminApp.loadOrders();
}

// 앱 초기화
let adminApp;
document.addEventListener('DOMContentLoaded', () => {
    adminApp = new AdminApp();
});
