// 키오스크 메인 애플리케이션
class KioskApp {
    constructor() {
        this.currentScreen = 'welcome';
        this.cart = [];
        this.categories = [];
        this.menus = [];
        this.currentCategory = null;
        this.socket = null;
        this.settings = {};
        
        this.init();
    }
    
    async init() {
        this.setupEventListeners();
        this.updateTime();
        this.loadSettings();
        this.connectSocket();
        await this.loadData();
    }
    
    setupEventListeners() {
        // 언어 선택
        document.querySelectorAll('.lang-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
            });
        });
        
        // 결제 방법 선택
        document.querySelectorAll('.payment-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.payment-btn').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
            });
        });
        
        // 키보드 이벤트 (키오스크 모드)
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.showWelcome();
            }
        });
        
        // 터치 이벤트 최적화
        document.addEventListener('touchstart', (e) => {
            e.preventDefault();
        }, { passive: false });
    }
    
    updateTime() {
        const now = new Date();
        const timeString = now.toLocaleTimeString('ko-KR', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        document.getElementById('current-time').textContent = timeString;
        
        setTimeout(() => this.updateTime(), 1000);
    }
    
    connectSocket() {
        // 오프라인 모드: Socket.io 연결 없이 실행
        console.log('오프라인 모드로 실행 중');
    }
    
    async loadSettings() {
        // 오프라인 모드: 기본 설정 사용
        this.settings = {
            store_name: 'KISK 키오스크',
            store_phone: '02-1234-5678',
            store_address: '서울시 강남구',
            tax_rate: '10',
            currency: 'KRW'
        };
        document.title = this.settings.store_name;
    }
    
    async loadData() {
        // 오프라인 모드: 샘플 데이터만 사용
        this.loadSampleData();
        this.renderCategories();
        // 메뉴는 카테고리 선택 시 로드됨
    }
    
    loadSampleData() {
        // 샘플 카테고리 데이터
        this.categories = [
            { id: 1, name: '메인메뉴', icon: '🍽️', display_order: 1 },
            { id: 2, name: '사이드메뉴', icon: '🍟', display_order: 2 },
            { id: 3, name: '음료', icon: '🥤', display_order: 3 },
            { id: 4, name: '디저트', icon: '🍰', display_order: 4 },
            { id: 5, name: '단일품', icon: '🍜', display_order: 5 }
        ];
        
        // 샘플 메뉴 데이터
        this.menus = [
            // 메인메뉴
            { id: 1, category_id: 1, name: '불고기버거', description: '한국식 불고기 패티와 신선한 야채', price: 8900, image_url: null, is_popular: true, display_order: 1 },
            { id: 2, category_id: 1, name: '치킨버거', description: '바삭한 치킨 패티와 특제 소스', price: 7900, image_url: null, is_popular: false, display_order: 2 },
            { id: 3, category_id: 1, name: '새우버거', description: '통새우 패티와 타르타르 소스', price: 9900, image_url: null, is_popular: true, display_order: 3 },
            { id: 4, category_id: 1, name: '치즈버거', description: '더블 치즈와 신선한 야채', price: 6900, image_url: null, is_popular: false, display_order: 4 },
            
            // 사이드메뉴
            { id: 5, category_id: 2, name: '감자튀김', description: '바삭한 감자튀김', price: 2500, image_url: null, is_popular: true, display_order: 1 },
            { id: 6, category_id: 2, name: '치킨너겟', description: '바삭한 치킨너겟 6개', price: 3500, image_url: null, is_popular: false, display_order: 2 },
            { id: 7, category_id: 2, name: '양파링', description: '바삭한 양파링', price: 3000, image_url: null, is_popular: false, display_order: 3 },
            { id: 8, category_id: 2, name: '치즈스틱', description: '치즈가 가득한 치즈스틱 4개', price: 4000, image_url: null, is_popular: true, display_order: 4 },
            
            // 음료
            { id: 9, category_id: 3, name: '콜라', description: '시원한 콜라', price: 2000, image_url: null, is_popular: true, display_order: 1 },
            { id: 10, category_id: 3, name: '사이다', description: '시원한 사이다', price: 2000, image_url: null, is_popular: false, display_order: 2 },
            { id: 11, category_id: 3, name: '오렌지주스', description: '신선한 오렌지주스', price: 3000, image_url: null, is_popular: false, display_order: 3 },
            { id: 12, category_id: 3, name: '아메리카노', description: '진한 아메리카노', price: 3500, image_url: null, is_popular: true, display_order: 4 },
            
            // 디저트
            { id: 13, category_id: 4, name: '아이스크림', description: '바닐라 아이스크림', price: 2000, image_url: null, is_popular: true, display_order: 1 },
            { id: 14, category_id: 4, name: '초콜릿케이크', description: '진한 초콜릿 케이크', price: 4500, image_url: null, is_popular: false, display_order: 2 },
            { id: 15, category_id: 4, name: '치즈케이크', description: '부드러운 치즈케이크', price: 4000, image_url: null, is_popular: true, display_order: 3 },
            { id: 16, category_id: 4, name: '애플파이', description: '달콤한 애플파이', price: 3500, image_url: null, is_popular: false, display_order: 4 },
            
            // 단일품 (새 카테고리)
            { id: 17, category_id: 5, name: '무삥', description: '매운 무삥 라면', price: 3500, image_url: null, is_popular: true, display_order: 1 },
            { id: 18, category_id: 5, name: '울버린', description: '울버린 라면', price: 3000, image_url: null, is_popular: true, display_order: 2 }
        ];
    }
    
    async loadCategories() {
        // 오프라인 모드: 샘플 데이터만 사용
        this.renderCategories();
    }
    
    async loadMenus() {
        // 오프라인 모드: 샘플 데이터만 사용
        // 메뉴는 이미 loadSampleData에서 로드됨
    }
    
    renderCategories() {
        const container = document.getElementById('category-grid');
        container.innerHTML = '';
        
        this.categories.forEach(category => {
            const card = document.createElement('div');
            card.className = 'category-card';
            card.innerHTML = `
                <i class="${category.icon || 'fas fa-utensils'}"></i>
                <h3>${category.name}</h3>
                <p>메뉴를 선택하세요</p>
            `;
            card.addEventListener('click', () => this.showMenu(category));
            container.appendChild(card);
        });
    }
    
    renderMenus(categoryId) {
        const container = document.getElementById('menu-grid');
        container.innerHTML = '';
        
        const categoryMenus = this.menus.filter(menu => menu.category_id == categoryId);
        
        categoryMenus.forEach(menu => {
            const card = document.createElement('div');
            card.className = 'menu-card';
            card.innerHTML = `
                ${menu.is_popular ? '<div class="menu-popular">인기</div>' : ''}
                <div class="menu-image">
                    ${menu.image_url ? 
                        `<img src="${menu.image_url}" alt="${menu.name}">` : 
                        '<i class="fas fa-utensils"></i>'
                    }
                </div>
                <div class="menu-info">
                    <div class="menu-name">${menu.name}</div>
                    <div class="menu-description">${menu.description || ''}</div>
                    <div class="menu-price">₩${menu.price.toLocaleString()}</div>
                </div>
            `;
            card.addEventListener('click', () => this.addToCart(menu));
            container.appendChild(card);
        });
    }
    
    renderCart() {
        const container = document.getElementById('cart-items');
        const countElement = document.getElementById('cart-count');
        const navCountElement = document.getElementById('nav-cart-count');
        
        container.innerHTML = '';
        
        if (this.cart.length === 0) {
            container.innerHTML = '<div style="text-align: center; padding: 40px; color: #6c757d;">장바구니가 비어있습니다</div>';
            countElement.textContent = '0';
            navCountElement.textContent = '0';
            document.querySelector('.checkout-btn').disabled = true;
            return;
        }
        
        let total = 0;
        
        this.cart.forEach((item, index) => {
            const cartItem = document.createElement('div');
            cartItem.className = 'cart-item';
            cartItem.innerHTML = `
                <div class="cart-item-image">
                    ${item.image_url ? 
                        `<img src="${item.image_url}" alt="${item.name}">` : 
                        '<i class="fas fa-utensils"></i>'
                    }
                </div>
                <div class="cart-item-info">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-price">₩${item.total_price.toLocaleString()}</div>
                </div>
                <div class="cart-item-controls">
                    <button class="quantity-btn" onclick="app.updateQuantity(${index}, -1)" ${item.quantity <= 1 ? 'disabled' : ''}>
                        <i class="fas fa-minus"></i>
                    </button>
                    <span class="quantity-display">${item.quantity}</span>
                    <button class="quantity-btn" onclick="app.updateQuantity(${index}, 1)">
                        <i class="fas fa-plus"></i>
                    </button>
                    <button class="remove-btn" onclick="app.removeFromCart(${index})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            container.appendChild(cartItem);
            total += item.total_price;
        });
        
        countElement.textContent = this.cart.length;
        navCountElement.textContent = this.cart.length;
        
        // 총액 계산
        const subtotal = total;
        const tax = Math.round(subtotal * 0.1);
        const totalAmount = subtotal + tax;
        
        document.getElementById('subtotal').textContent = `₩${subtotal.toLocaleString()}`;
        document.getElementById('tax').textContent = `₩${tax.toLocaleString()}`;
        document.getElementById('total').textContent = `₩${totalAmount.toLocaleString()}`;
        
        document.querySelector('.checkout-btn').disabled = false;
    }
    
    renderCheckoutItems() {
        const container = document.getElementById('checkout-items');
        container.innerHTML = '';
        
        let total = 0;
        
        this.cart.forEach(item => {
            const checkoutItem = document.createElement('div');
            checkoutItem.className = 'checkout-item';
            checkoutItem.innerHTML = `
                <span>${item.name} x${item.quantity}</span>
                <span>₩${item.total_price.toLocaleString()}</span>
            `;
            container.appendChild(checkoutItem);
            total += item.total_price;
        });
        
        const tax = Math.round(total * 0.1);
        const totalAmount = total + tax;
        
        document.getElementById('checkout-total').textContent = `₩${totalAmount.toLocaleString()}`;
    }
    
    showScreen(screenId) {
        document.querySelectorAll('.screen').forEach(screen => {
            screen.classList.remove('active');
        });
        document.getElementById(screenId).classList.add('active');
        this.currentScreen = screenId;
    }
    
    showWelcome() {
        this.showScreen('welcome-screen');
    }
    
    showCategories() {
        this.showScreen('category-screen');
    }
    
    showMenu(category) {
        this.currentCategory = category;
        document.getElementById('menu-category-title').textContent = category.name;
        this.renderMenus(category.id);
        this.showScreen('menu-screen');
    }
    
    showCart() {
        this.renderCart();
        this.showScreen('cart-screen');
    }
    
    showCheckout() {
        this.renderCheckoutItems();
        this.showScreen('checkout-screen');
    }
    
    showOrderComplete(orderNumber) {
        document.getElementById('order-number').textContent = orderNumber;
        this.showScreen('order-complete-screen');
    }
    
    showHelp() {
        document.getElementById('help-modal').classList.add('active');
    }
    
    closeHelp() {
        document.getElementById('help-modal').classList.remove('active');
    }
    
    addToCart(menu) {
        const existingItem = this.cart.find(item => item.id === menu.id);
        
        if (existingItem) {
            existingItem.quantity += 1;
            existingItem.total_price = existingItem.quantity * existingItem.unit_price;
        } else {
            this.cart.push({
                id: menu.id,
                name: menu.name,
                unit_price: menu.price,
                quantity: 1,
                total_price: menu.price,
                image_url: menu.image_url
            });
        }
        
        this.renderCart();
        this.showCart();
    }
    
    updateQuantity(index, change) {
        const item = this.cart[index];
        item.quantity += change;
        
        if (item.quantity <= 0) {
            this.cart.splice(index, 1);
        } else {
            item.total_price = item.quantity * item.unit_price;
        }
        
        this.renderCart();
    }
    
    removeFromCart(index) {
        this.cart.splice(index, 1);
        this.renderCart();
    }
    
    async processPayment() {
        this.showLoading(true);
        
        try {
            const paymentMethod = document.querySelector('.payment-btn.active').dataset.method;
            const customerName = document.getElementById('customer-name').value;
            const customerPhone = document.getElementById('customer-phone').value;
            
            let total = 0;
            this.cart.forEach(item => total += item.total_price);
            const tax = Math.round(total * 0.1);
            const totalAmount = total + tax;
            
            // 오프라인 모드: 시뮬레이션으로 주문 처리
            const orderNumber = 'ORD' + Date.now();
            
            // 결제 시뮬레이션
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // 주문 완료 처리
            this.cart = [];
            this.showOrderComplete(orderNumber);
            
        } catch (error) {
            console.error('결제 처리 실패:', error);
            alert('결제 처리 중 오류가 발생했습니다: ' + error.message);
        } finally {
            this.showLoading(false);
        }
    }
    
    startNewOrder() {
        this.cart = [];
        this.showWelcome();
    }
    
    showLoading(show) {
        const overlay = document.getElementById('loading-overlay');
        if (show) {
            overlay.classList.add('active');
        } else {
            overlay.classList.remove('active');
        }
    }
}

// 전역 함수들 (HTML에서 호출)
function startOrder() {
    app.showCategories();
}

function showWelcome() {
    app.showWelcome();
}

function showCategories() {
    app.showCategories();
}

function showCart() {
    app.showCart();
}

function showCheckout() {
    app.showCheckout();
}

function showHelp() {
    app.showHelp();
}

function closeHelp() {
    app.closeHelp();
}

function startNewOrder() {
    app.startNewOrder();
}

// 앱 초기화
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new KioskApp();
});

// 키오스크 모드 설정
document.addEventListener('DOMContentLoaded', () => {
    // 전체화면 모드
    if (document.documentElement.requestFullscreen) {
        document.documentElement.requestFullscreen();
    }
    
    // 컨텍스트 메뉴 비활성화
    document.addEventListener('contextmenu', (e) => {
        e.preventDefault();
    });
    
    // 선택 비활성화
    document.addEventListener('selectstart', (e) => {
        e.preventDefault();
    });
    
    // 드래그 비활성화
    document.addEventListener('dragstart', (e) => {
        e.preventDefault();
    });
});
