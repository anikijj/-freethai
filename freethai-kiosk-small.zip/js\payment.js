// 결제 시스템 모듈
class PaymentSystem {
    constructor() {
        this.paymentMethods = {
            card: {
                name: '신용카드',
                icon: 'fas fa-credit-card',
                enabled: true
            },
            mobile: {
                name: '모바일페이',
                icon: 'fas fa-mobile-alt',
                enabled: true
            },
            cash: {
                name: '현금',
                icon: 'fas fa-won-sign',
                enabled: true
            }
        };
        
        this.init();
    }
    
    init() {
        this.setupPaymentHandlers();
    }
    
    setupPaymentHandlers() {
        // 결제 방법 선택 이벤트
        document.addEventListener('click', (e) => {
            if (e.target.closest('.payment-btn')) {
                this.selectPaymentMethod(e.target.closest('.payment-btn').dataset.method);
            }
        });
        
        // 결제 처리 이벤트
        document.addEventListener('click', (e) => {
            if (e.target.closest('.process-payment-btn')) {
                this.processPayment();
            }
        });
    }
    
    selectPaymentMethod(method) {
        // 모든 결제 버튼 비활성화
        document.querySelectorAll('.payment-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // 선택된 결제 방법 활성화
        const selectedBtn = document.querySelector(`[data-method="${method}"]`);
        if (selectedBtn) {
            selectedBtn.classList.add('active');
        }
    }
    
    async processPayment() {
        const selectedMethod = document.querySelector('.payment-btn.active');
        if (!selectedMethod) {
            alert('결제 방법을 선택해주세요');
            return;
        }
        
        const method = selectedMethod.dataset.method;
        const cart = window.app ? window.app.cart : [];
        
        if (cart.length === 0) {
            alert('장바구니가 비어있습니다');
            return;
        }
        
        try {
            // 결제 처리 시작
            this.showPaymentProcessing(true);
            
            // 결제 방법별 처리
            switch (method) {
                case 'card':
                    await this.processCardPayment(cart);
                    break;
                case 'mobile':
                    await this.processMobilePayment(cart);
                    break;
                case 'cash':
                    await this.processCashPayment(cart);
                    break;
                default:
                    throw new Error('지원하지 않는 결제 방법입니다');
            }
            
        } catch (error) {
            console.error('결제 처리 실패:', error);
            alert('결제 처리 중 오류가 발생했습니다: ' + error.message);
        } finally {
            this.showPaymentProcessing(false);
        }
    }
    
    async processCardPayment(cart) {
        // 신용카드 결제 시뮬레이션
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // 카드 결제 성공 시뮬레이션 (90% 성공률)
                if (Math.random() > 0.1) {
                    this.showCardPaymentUI(() => {
                        resolve({
                            success: true,
                            transactionId: 'TXN' + Date.now(),
                            method: 'card'
                        });
                    });
                } else {
                    reject(new Error('카드 결제가 실패했습니다. 카드를 다시 확인해주세요.'));
                }
            }, 2000);
        });
    }
    
    async processMobilePayment(cart) {
        // 모바일페이 결제 시뮬레이션
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // 모바일페이 결제 성공 시뮬레이션 (95% 성공률)
                if (Math.random() > 0.05) {
                    this.showMobilePaymentUI(() => {
                        resolve({
                            success: true,
                            transactionId: 'MOB' + Date.now(),
                            method: 'mobile'
                        });
                    });
                } else {
                    reject(new Error('모바일페이 결제가 실패했습니다. 다시 시도해주세요.'));
                }
            }, 1500);
        });
    }
    
    async processCashPayment(cart) {
        // 현금 결제 처리
        return new Promise((resolve) => {
            this.showCashPaymentUI(cart, (result) => {
                resolve({
                    success: result.success,
                    transactionId: 'CASH' + Date.now(),
                    method: 'cash',
                    change: result.change
                });
            });
        });
    }
    
    showCardPaymentUI(callback) {
        // 카드 결제 UI 표시
        const modal = this.createPaymentModal('신용카드 결제', `
            <div class="payment-card-ui">
                <div class="card-slot">
                    <i class="fas fa-credit-card"></i>
                    <p>카드를 리더기에 넣어주세요</p>
                </div>
                <div class="payment-progress">
                    <div class="progress-bar">
                        <div class="progress-fill"></div>
                    </div>
                    <p>결제 처리 중...</p>
                </div>
            </div>
        `);
        
        // 진행률 애니메이션
        const progressFill = modal.querySelector('.progress-fill');
        let progress = 0;
        const interval = setInterval(() => {
            progress += 10;
            progressFill.style.width = progress + '%';
            
            if (progress >= 100) {
                clearInterval(interval);
                setTimeout(() => {
                    this.closePaymentModal();
                    callback();
                }, 500);
            }
        }, 200);
    }
    
    showMobilePaymentUI(callback) {
        // 모바일페이 결제 UI 표시
        const modal = this.createPaymentModal('모바일페이 결제', `
            <div class="payment-mobile-ui">
                <div class="qr-code">
                    <div class="qr-placeholder">
                        <i class="fas fa-qrcode"></i>
                        <p>QR코드를 스캔하세요</p>
                    </div>
                </div>
                <div class="mobile-payment-methods">
                    <div class="method-item">
                        <i class="fas fa-mobile-alt"></i>
                        <span>Samsung Pay</span>
                    </div>
                    <div class="method-item">
                        <i class="fas fa-mobile-alt"></i>
                        <span>Apple Pay</span>
                    </div>
                    <div class="method-item">
                        <i class="fas fa-mobile-alt"></i>
                        <span>Google Pay</span>
                    </div>
                </div>
                <div class="payment-progress">
                    <div class="progress-bar">
                        <div class="progress-fill"></div>
                    </div>
                    <p>결제 확인 중...</p>
                </div>
            </div>
        `);
        
        // 진행률 애니메이션
        const progressFill = modal.querySelector('.progress-fill');
        let progress = 0;
        const interval = setInterval(() => {
            progress += 15;
            progressFill.style.width = progress + '%';
            
            if (progress >= 100) {
                clearInterval(interval);
                setTimeout(() => {
                    this.closePaymentModal();
                    callback();
                }, 500);
            }
        }, 150);
    }
    
    showCashPaymentUI(cart, callback) {
        const total = this.calculateTotal(cart);
        
        const modal = this.createPaymentModal('현금 결제', `
            <div class="payment-cash-ui">
                <div class="cash-info">
                    <h3>결제 금액</h3>
                    <p class="total-amount">₩${total.toLocaleString()}</p>
                </div>
                <div class="cash-input">
                    <label for="cash-amount">받은 금액</label>
                    <input type="number" id="cash-amount" min="${total}" step="1000" placeholder="받은 금액을 입력하세요">
                    <button class="calculate-btn" onclick="paymentSystem.calculateChange()">거스름돈 계산</button>
                </div>
                <div class="change-info" id="change-info" style="display: none;">
                    <h4>거스름돈</h4>
                    <p class="change-amount" id="change-amount">₩0</p>
                </div>
                <div class="cash-actions">
                    <button class="cancel-btn" onclick="paymentSystem.closePaymentModal()">취소</button>
                    <button class="confirm-btn" onclick="paymentSystem.confirmCashPayment()">결제 완료</button>
                </div>
            </div>
        `);
        
        this.cashCallback = callback;
    }
    
    calculateChange() {
        const total = this.calculateTotal(window.app ? window.app.cart : []);
        const received = parseFloat(document.getElementById('cash-amount').value) || 0;
        
        if (received < total) {
            alert('받은 금액이 결제 금액보다 적습니다');
            return;
        }
        
        const change = received - total;
        document.getElementById('change-amount').textContent = `₩${change.toLocaleString()}`;
        document.getElementById('change-info').style.display = 'block';
    }
    
    confirmCashPayment() {
        const total = this.calculateTotal(window.app ? window.app.cart : []);
        const received = parseFloat(document.getElementById('cash-amount').value) || 0;
        
        if (received < total) {
            alert('받은 금액이 결제 금액보다 적습니다');
            return;
        }
        
        const change = received - total;
        this.closePaymentModal();
        this.cashCallback({
            success: true,
            change: change
        });
    }
    
    calculateTotal(cart) {
        let total = 0;
        cart.forEach(item => {
            total += item.total_price;
        });
        return total;
    }
    
    createPaymentModal(title, content) {
        // 기존 모달 제거
        this.closePaymentModal();
        
        const modal = document.createElement('div');
        modal.className = 'payment-modal active';
        modal.innerHTML = `
            <div class="payment-modal-content">
                <div class="payment-modal-header">
                    <h3>${title}</h3>
                    <button class="close-btn" onclick="paymentSystem.closePaymentModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="payment-modal-body">
                    ${content}
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        return modal;
    }
    
    closePaymentModal() {
        const existingModal = document.querySelector('.payment-modal');
        if (existingModal) {
            existingModal.remove();
        }
    }
    
    showPaymentProcessing(show) {
        const overlay = document.getElementById('loading-overlay');
        if (overlay) {
            if (show) {
                overlay.classList.add('active');
            } else {
                overlay.classList.remove('active');
            }
        }
    }
    
    // 결제 완료 후 주문 생성
    async createOrder(paymentResult, cart) {
        try {
            const total = this.calculateTotal(cart);
            const tax = Math.round(total * 0.1);
            const totalAmount = total + tax;
            
            const orderData = {
                items: cart.map(item => ({
                    menu_id: item.id,
                    quantity: item.quantity,
                    unit_price: item.unit_price,
                    total_price: item.total_price
                })),
                total_amount: totalAmount,
                payment_method: paymentResult.method,
                customer_name: document.getElementById('customer-name')?.value || null,
                customer_phone: document.getElementById('customer-phone')?.value || null
            };
            
            const response = await fetch('/api/orders', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(orderData)
            });
            
            const result = await response.json();
            
            if (response.ok) {
                return {
                    success: true,
                    orderNumber: result.order_number,
                    orderId: result.order_id
                };
            } else {
                throw new Error(result.error || '주문 생성 실패');
            }
        } catch (error) {
            console.error('주문 생성 실패:', error);
            throw error;
        }
    }
}

// 결제 시스템 초기화
let paymentSystem;
document.addEventListener('DOMContentLoaded', () => {
    paymentSystem = new PaymentSystem();
});

// 전역 함수들
function calculateChange() {
    if (paymentSystem) {
        paymentSystem.calculateChange();
    }
}

function confirmCashPayment() {
    if (paymentSystem) {
        paymentSystem.confirmCashPayment();
    }
}
